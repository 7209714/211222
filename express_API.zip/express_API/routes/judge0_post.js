var express = require('express');
const request = require('request');
var router = express.Router();


var back_json=""
router.use( function (req,res) {
    
  var data1=req.body.data1
  var cin1=req.body.cin1
  var data2=req.body.data2
  var cin2=req.body.cin2

  const buff1 = Buffer.from(data1, 'utf-8');
  const buff_cin1 = Buffer.from(cin1, 'utf-8');
  const buff2 = Buffer.from(data2, 'utf-8');
  const buff_cin2 = Buffer.from(cin2, 'utf-8');
  // encode buffer as Base64
  const base64data1 = buff1.toString('base64');
  const base64data_cin1 = buff_cin1.toString('base64');
  const base64data2 = buff2.toString('base64');
  const base64data_cin2 = buff_cin2.toString('base64');
  //console.log(base64data);


    

    const options = {
        method: 'POST',
        url: 'http://172.24.96.1:2358/submissions/batch',
        qs: {base64_encoded: 'true'},
        headers: {
          'content-type': 'application/json',
          'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
          'x-rapidapi-key': 'c14f7d728bmsh45872963b9f4ce7p16fd97jsn00e4bac8960d',
          'useQueryString': true
        },
        body: {
          submissions: [
            {language_id: 52, source_code: base64data1,stdin:base64data_cin1},
            {language_id: 52, source_code: base64data2,stdin:base64data_cin2},
            
          ]
        },
        json: true
      };
      
      request(options, function (error, response, body) {
        if (error) throw new Error(error);

          test=body[0].token+","+body[1].token;
          console.log(test);
          
      
          //--------------------------------------------------GET---------------------------//
        const options_g = {
              method: 'GET',
              url: 'http://172.24.96.1:2358/submissions/batch',
              qs: {
                tokens:test,
                base64_encoded: 'true',
                fields: "*",
              },
              headers: {
                'content-type': 'application/json',
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
               'x-rapidapi-key': 'c14f7d728bmsh45872963b9f4ce7p16fd97jsn00e4bac8960d',
                'useQueryString': true
              }
            };


        setTimeout(() => { 
              request(options_g, function (error,response, body) {
                if (error) {
                  console.log(error);
                  res.sendStatus(500);
                  return;
                }
                for(var i=1;i<100000;i++)
                {
                 //   console.log(i)
                }
                var body_json=JSON.parse(body);
       //         console.log(body_json)
                
                  var err1=""
                  var err2=""
                  var test1=""
                  var test2=""
                   if(body_json["submissions"][0]["compile_output"]!=null)
                   {
                    err1=body_json["submissions"][0]["compile_output"]

                    test1=Buffer.from(err1, 'base64').toString('utf-8')
                    console.log(test1)
                   }
                   else{
                    err1=body_json["submissions"][0]["stdout"]

                    test1=Buffer.from(err1, 'base64').toString('utf-8')
                    console.log(test1)
                   }
                   if(body_json["submissions"][1]["compile_output"]!=null)
                   {
                    err2=body_json["submissions"][1]["compile_output"]

                    test2=Buffer.from(err2, 'base64').toString('utf-8')
                    console.log(test2)
                   }
                   else{
                    err2=body_json["submissions"][1]["stdout"]

                    test2=Buffer.from(err2, 'base64').toString('utf-8')
                    console.log(test2)
                   }
                   var err_back={GET1回傳:test1,GET2回傳:test2}
                   res.json(err_back)
                   
                  
                
                      
              })
            

        },60000);

    
 
    
});
})
        
module.exports = router;
